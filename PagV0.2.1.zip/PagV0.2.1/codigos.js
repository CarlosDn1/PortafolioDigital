    

function validarpassword(){ //Crea una funcion
    var password = document.getElementById("password").value; //Obtiene el valor de password con el id "password" 
    var confirm_password = document.getElementById("confirm_password").value; //Obtiene el valor de confirm_password con el id "confirm_password"
    var name = document.getElementsByName("name")[0].value; //Obtiene el valor de name
    var email = document.getElementsByName("email")[0].value; //Obtiene el valor de email
    var birthdate = document.getElementsByName("birthdate")[0].value; //Obtiene el valor birthdates

    if (name === "" || email === "" || birthdate === "" || password === "" || confirm_password === "") {
        // Si algún campo está vacío, mostrar un mensaje de alerta y evitar la redirección
        alert("Por favor, llene todos los campos del formulario."); //Envia un mensaje
        return false; // Evitar el envío del formulario
    } else {
        if (password === confirm_password) {
            // Redirigir a la siguiente página si las contraseñas coinciden
            window.location.href = "PaginaPrincipal.html";
            return true; // Permitir el envío del formulario
        } else {
            alert("Las contraseñas no coinciden.");
            return false; // Evitar el envío del formulario
        }
    }
        
}

